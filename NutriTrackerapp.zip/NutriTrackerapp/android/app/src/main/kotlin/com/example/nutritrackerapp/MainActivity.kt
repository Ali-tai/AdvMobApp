package com.example.nutritrackerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
