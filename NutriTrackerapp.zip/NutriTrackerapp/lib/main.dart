import 'package:flutter/material.dart';

import 'package:nutritrackerapp/screens/nutri_track.dart';
import 'package:nutritrackerapp/screens/summary.dart';
import 'package:nutritrackerapp/screens/scan.dart';
import 'package:nutritrackerapp/screens/personal_info.dart';
import 'package:nutritrackerapp/screens/allergies.dart';
import 'package:nutritrackerapp/screens/macros.dart';


void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'NutriTracker',
      theme: ThemeData(
        primarySwatch: Colors.green,
        scaffoldBackgroundColor: Colors.white,
        textTheme: TextTheme(
          bodyLarge: TextStyle(color: Colors.black),
          bodyMedium: TextStyle(color: Colors.black),
        ),
      ),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('NutriTracker'),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        children: [
          NutriTrackButton(),
          SummaryButton(),
          ScanButton(),
          PersonalInfoButton(),
          AllergiesButton(),
          MacrosButton(),
        ],
      ),
    );
  }
}

class NutriTrackButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => NutriTrack()),
          );
        },
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.home, size: 48),
              SizedBox(height: 8),
              Text('NutriTrack'),
            ],
          ),
        ),
      ),
    );
  }
}

class SummaryButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => Summary()),
          );
        },
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.summarize, size: 48),
              SizedBox(height: 8),
              Text('Summary'),
            ],
          ),
        ),
      ),
    );
  }
}

class ScanButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => Scan()),
          );
        },
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.qr_code_scanner, size: 48),
              SizedBox(height: 8),
              Text('Scan'),
            ],
          ),
        ),
      ),
    );
  }
}

class PersonalInfoButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => PersonalInfo()),
          );
        },
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.person, size: 48),
              SizedBox(height: 8),
              Text('Info Person'),
            ],
          ),
        ),
      ),
    );
  }
}

class AllergiesButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => Allergies()),
          );
        },
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.warning, size: 48),
              SizedBox(height: 8),
              Text('Allergies'),
            ],
          ),
        ),
      ),
    );
  }
}

class MacrosButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => Macros()),
          );
        },
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.bar_chart, size: 48),
              SizedBox(height: 8),
              Text('Macro'),
            ],
          ),
        ),
      ),
    );
  }
}