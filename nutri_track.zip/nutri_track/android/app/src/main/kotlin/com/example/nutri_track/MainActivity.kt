package com.example.nutri_track

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
